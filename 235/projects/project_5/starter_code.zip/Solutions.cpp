#include "DoublyLinkedList.hpp"
#include <string>

namespace solutions
{
    /* Bubblesort */
    template <typename Comparable, typename Comparator>
    void bubbleSort(DoublyLinkedList<Comparable> &a_list, const Comparator &comp)
    {
    }

    /* Insertionsort */
    template <typename Comparable, typename Comparator>
    void insertionSort(DoublyLinkedList<Comparable> &a_list, const Comparator &comp)
    {
    }

    /* Merge */
    template <typename Comparable, typename Comparator>
    void merge(DoublyLinkedList<Comparable> &a_list, int left_index, int middle_index, int right_index, const Comparator &comp)
    {
    }

    /* Mergesort */
    template <typename Comparable, typename Comparator>
    void mergeSort(DoublyLinkedList<Comparable> &a_list, int left_index, int right_index, const Comparator &comp)
    {
    }

    /* Mergesort Wrapper */
    template <typename Comparable, typename Comparator>
    void mergeSort(DoublyLinkedList<Comparable> &a_list, const Comparator &comp)
    {
    }

}; // namespace solutions

/* DO NOT USE THESE: 
    * Shellsort *
    template <typename Comparable, typename Comparator>
    void shellSort(DoublyLinkedList<Comparable> &a_list, const Comparator &comp)
    {
    }
    * Quicksort *
    template <typename Comparable, typename Comparator>
    void quicksort(DoublyLinkedList<Comparable> &a_list, int left_index, int right_index, const Comparator &comp)
    {
    }
    * Quicksort Wrapper *
    template <typename Comparable, typename Comparator>
    void quickSort(DoublyLinkedList<Comparable> &a_list, const Comparator &comp)
    {
    }
*/