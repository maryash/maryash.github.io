#include "Produce.hpp"

#include <iostream>
#include <fstream>

Produce::Produce() : name_{""}, weight_(0), price_per_pound_{0}, is_organic_{0}, is_pre_packaged_{0}, ripeness_{0}, condition_{0}
{
}

/* Parameterized Constructor */
Produce::Produce(const std::string &in_file)
{
    std::fstream fin;                // instantiates a filestream variable
    fin.open(in_file, std::ios::in); // assigns to it the content of the product file
    if (fin.fail())
    {
        std::cerr << "File cannot be opened. Produce object cannot be constructed." << std::endl;
        return;
    }
    std::string junk, chunk;
    getline(fin, junk);

    /* The extraction operator is able to infer the type
       of the input stream from file in given the respective 
       context of each private member type 
    */
    fin >> name_;
    fin >> weight_;
    fin >> price_per_pound_;
    fin >> is_organic_;
    fin >> is_pre_packaged_;
    fin >> ripeness_;
    fin >> condition_;

    fin.close();
}

/* Accessor that yields name_ */
std::string Produce::getName() const
{
    return name_;
}

/* Accessor that yields weight_ */
double Produce::getWeight() const
{
    return weight_;
}

/* Accessor that yields price_per_pound_ */
double Produce::getPricePerPound() const
{
    return price_per_pound_;
}

/* Accessor that yields is_organic_ */
bool Produce::getOrganic() const
{
    return is_organic_;
}

/* Accessor that yields is_pre_packaged */
bool Produce::getPrePackaged() const
{
    return is_pre_packaged_;
}

/* Accessor that yields ripeness */
int Produce::getRipeness() const
{
    return ripeness_;
}

/* Accessor that yields condition_ */
int Produce::getCondition() const
{
    return condition_;
}

/* Accessor that yields a string version of ripeness_ */
std::string Produce::getRipenessStr() const
{
    std::string ripeness_strings[3] = {"overripe", "underripe", "ripe"};
    return ripeness_strings[ripeness_];
}

/* Accessor that yields a string version of condition_ */
std::string Produce::getConditionStr() const
{
    std::string condition_strings[2] = {"damaged", "undamaged"};
    return condition_strings[condition_];
}