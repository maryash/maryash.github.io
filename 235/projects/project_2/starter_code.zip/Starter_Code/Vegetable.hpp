#ifndef VEGETABLE_
#define VEGETABLE_

#include "Produce.hpp"
#include <iostream>

namespace categories
{
    enum veggie_categories
    {
        ALLIUM = 0,
        CRUCIFEROUS = 1,
        EDIBLE_STEM = 2,
        LEAFY_GREEN = 3,
        LEGUME = 4,
        MARROW = 5,
        ROOT = 6

    };
} // namespace categories

class Vegetable : public Produce
{
private:
    int veggie_type_;

public:
    Vegetable();
    Vegetable(const std::string &in_file);
    std::string getVeggieType();
}; // end Vegetable
#endif
