#ifndef FRUIT_
#define FRUIT_

#include "Produce.hpp"
#include <iostream>

class Fruit : public Produce
{
private:
    bool is_pitted_;
    bool has_peelable_skin_;
    bool has_rind_;
    bool has_edible_seeds;

public:
    Fruit();
    Fruit(const std::string &in_file);
    bool getPitted();
    bool getPeelableSkin();
    bool getRind();
    bool getEdibleSeeds();
    /* 

            When you use these as stream operators (rather than binary shift) the 
            first parameter is a stream. Since you do not have access to the stream 
            object (its not yours to modify) these can not be member operators they have 
            to be external to the class. Thus they must either be friends of the class or 
            have access to a public method that will do the streaming for you.

            It is also traditional for these objects to return a reference to a stream object 
            so you can chain stream operations together.
    */

}; // end Fruit
#endif