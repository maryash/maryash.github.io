#include "Fruit.hpp"

#include <string>
#include <iostream>
#include <fstream>

Fruit::Fruit() : is_pitted_{0}, has_peelable_skin_{0}, has_rind_{0}, has_edible_seeds{0}
{
}

/* Parameterized Constructor */
Fruit::Fruit(const std::string &in_file) : Produce(in_file)
{
    std::fstream fin;                // instantiates a filestream variable
    fin.open(in_file, std::ios::in); // assigns to it the content of the product file
    if (fin.fail())
    {
        std::cerr << "File cannot be opened. Fruit object cannot be constructed." << std::endl;
        return;
    }
    std::string junk;
    getline(fin, junk);

    for (size_t i = 0; i < 7; i++)
    {
        fin >> junk;
    }

    /* The extraction operator is able to infer the type
       of the input stream from file in given the respective 
       context of each private member type 
    */
    fin >> is_pitted_;
    fin >> has_peelable_skin_;
    fin >> has_rind_;
    fin >> has_edible_seeds;
    fin.close();
}

/* Accessor that yields is_pitted_ */
bool Fruit::getPitted()
{
    return is_pitted_;
}

/* Accessor that yields has_peelable_skin_ */
bool Fruit::getPeelableSkin()
{
    return has_peelable_skin_;
}

/* Accessor that yields has_rind */
bool Fruit::getRind()
{
    return has_rind_;
}

/* Accessor that yields has_edible_seeds */
bool Fruit::getEdibleSeeds()
{
    return has_edible_seeds;
}
