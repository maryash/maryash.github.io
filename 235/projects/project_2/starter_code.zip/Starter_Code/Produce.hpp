#include <string>

#ifndef PRODUCE_
#define PRODUCE_

namespace produce_details
{
    enum ripeness
    {
        OVERRIPE = 0,
        UNDERRIPE = 1,
        RIPE = 2
    };
    enum conditions
    {
        DAMAGED = 0,
        UNDAMAGED = 1
    };
} // namespace produce_details

class Produce
{
private:
    std::string name_;
    double weight_;
    double price_per_pound_;
    bool is_organic_;
    bool is_pre_packaged_;
    int ripeness_;
    int condition_;

public:
    Produce();
    Produce(const std::string &in_file);
    std::string getName() const;
    double getWeight() const;
    double getPricePerPound() const;
    bool getOrganic() const;
    bool getPrePackaged() const;
    int getRipeness() const;
    int getCondition() const;
    std::string getRipenessStr() const;
    std::string getConditionStr() const;
}; // end Produce
#endif