#include "Vegetable.hpp"

#include <string>
#include <iostream>
#include <fstream>

Vegetable::Vegetable() : veggie_type_{0}
{
}

/* Parameterized Constructor */
Vegetable::Vegetable(const std::string &in_file) : Produce(in_file)
{
    std::fstream fin;                // instantiates a filestream variable
    fin.open(in_file, std::ios::in); // assigns to it the content of the product file
    if (fin.fail())
    {
        std::cerr << "File cannot be opened. Fruit object cannot be constructed." << std::endl;
        return;
    }
    std::string junk;
    getline(fin, junk);

    for (size_t i = 0; i < 7; i++)
    {
        fin >> junk;
    }

    /* The extraction operator is able to infer the type
       of the input stream from file in given the respective 
       context of each private member type 
    */
    fin >> veggie_type_;
}

/* Accessor that yields a string version of veggie_type_ */
std::string Vegetable::getVeggieType()
{
    std::string vegetable_strings[7] = {"allium", "cruciferous", "edible stem", "leafy green", "legume", "marrow", "root"};
    return vegetable_strings[veggie_type_];
}