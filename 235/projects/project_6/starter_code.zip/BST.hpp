/****************************************************************************************************************************
Title        : BST.hpp
Auhor        : Nigel Ferrer & Yash Mahtani
Description  : header/interface file of a Binary Search Tree class with limited functionality
Dependencies : BinaryNode.hpp, BinaryNode.cpp
Addendum     : DO NOT ALTER THIS FILE 
****************************************************************************************************************************/

#ifndef BST_
#define BST_

#include "BinaryNode.hpp"
#include <vector>

template <class T>
class BST
{
public:
    BST();
    ~BST();
    void clear(std::shared_ptr<BinaryNode<T>> subtree_root);
    bool isEmpty();
    bool insert(const T &item);
    bool insert_vec(std::vector<T> group);

    std::shared_ptr<BinaryNode<T>> getRoot() const;

    friend void inOrderTraversal(std::shared_ptr<BinaryNode<T>> subtree_root);
    friend void preOrderTraversal(std::shared_ptr<BinaryNode<T>> subtree_root);
    friend void postOrderTraversal(std::shared_ptr<BinaryNode<T>> subtree_root);

private:
    std::shared_ptr<BinaryNode<T>> insert(std::shared_ptr<BinaryNode<T>> subtree_root,
                                          std::shared_ptr<BinaryNode<T>> new_node_);
    std::shared_ptr<BinaryNode<T>> root_;
};

#include "BST.cpp"
#include "Solutions.cpp"
#endif