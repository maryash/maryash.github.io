#include <iostream>

template <class T>
void inOrderTraversal(std::shared_ptr<BinaryNode<T>> subtree_root)
{
}

template <class T>
void postOrderTraversal(std::shared_ptr<BinaryNode<T>> subtree_root)
{
}

template <class T>
void preOrderTraversal(std::shared_ptr<BinaryNode<T>> subtree_root)
{
}