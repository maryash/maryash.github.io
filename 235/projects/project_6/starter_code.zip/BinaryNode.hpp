/****************************************************************************************************************************
Title        : BinaryNode.hpp
Auhor        : Frank M. Carrano and Timothy M. Henry.
Modified By  : Nigel Ferrer & Yash Mahtani
Description  : header/interface file of a Binary Node class
Dependencies : BinaryNode.cpp
Addendum     : DO NOT ALTER THIS FILE 
****************************************************************************************************************************/

#ifndef BINARY_NODE_
#define BINARY_NODE_

#include <memory>

template <class T>
class BinaryNode
{
private:
   T item_;
   std::shared_ptr<BinaryNode<T>> leftChildPtr;
   std::shared_ptr<BinaryNode<T>> rightChildPtr;

public:
   BinaryNode();
   explicit BinaryNode(const T &anItem);
   BinaryNode(const T &anItem,
              std::shared_ptr<BinaryNode<T>> leftPtr,
              std::shared_ptr<BinaryNode<T>> rightPtr);

   void setItem(const T &anItem);
   T getItem() const;

   bool isLeaf() const;

   auto getLeftChildPtr() const;
   auto getRightChildPtr() const;

   void setLeftChildPtr(std::shared_ptr<BinaryNode<T>> leftPtr);
   void setRightChildPtr(std::shared_ptr<BinaryNode<T>> rightPtr);
};

#include "BinaryNode.cpp"
#endif
