/****************************************************************************************************************************
Title        : BST.cpp
Auhor        : Nigel Ferrer & Yash Mahtani
Description  : implementation file of a Binary Search Tree class with limited functionality
Dependencies : BinaryNode.hpp, BinaryNode.cpp
Addendum     : DO NOT ALTER THIS FILE 
****************************************************************************************************************************/

/* Default Constructor */
template <class T>
BST<T>::BST() : root_{nullptr}
{
}

/* Destructor */
template <class T>
BST<T>::~BST()
{
    clear(root_);
}

// recursively releases memory used by tree
template <class T>
void BST<T>::clear(std::shared_ptr<BinaryNode<T>> subtree_root)
{
    if (subtree_root != nullptr)
    {
        clear(subtree_root->getLeftChildPtr());
        clear(subtree_root->getRightChildPtr());
        subtree_root.reset();
    }
}

/* Accessor: root_ */
template <class T>
std::shared_ptr<BinaryNode<T>> BST<T>::getRoot() const
{
    return root_;
}

/* Accessor: root_ == nullptr ? */
template <class T>
bool BST<T>::isEmpty()
{
    return root_ == nullptr;
}

// wrapper for recursive insert
template <class T>
bool BST<T>::insert(const T &item)
{
    root_ = insert(root_, std::make_shared<BinaryNode<T>>(item));
    return true;
}

// inserts from a vector
template <class T>
bool BST<T>::insert_vec(std::vector<T> group)
{
    for (T i : group)
    {
        insert(i);
    }
    return true;
}

// recursive insert
template <class T>
std::shared_ptr<BinaryNode<T>> BST<T>::insert(std::shared_ptr<BinaryNode<T>> subtree_root, std::shared_ptr<BinaryNode<T>> new_node)
{
    if (subtree_root == nullptr)
    {
        return new_node;
    }
    else
    {
        if (new_node->getItem() < subtree_root->getItem())
        {
            subtree_root->setLeftChildPtr(insert(subtree_root->getLeftChildPtr(), new_node));
        }
        else
        {
            subtree_root->setRightChildPtr(insert(subtree_root->getRightChildPtr(), new_node));
        }
        return subtree_root;
    }
}