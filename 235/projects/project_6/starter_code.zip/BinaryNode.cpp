/****************************************************************************************************************************
Title        : BinaryNode.cpp
Auhor        : Frank M. Carrano and Timothy M. Henry.
Modified By  : Nigel Ferrer & Yash Mahtani
Description  : implementation file of a Binary Node class
Dependencies : BinaryNode.hpp
Addendum     : DO NOT ALTER THIS FILE 
****************************************************************************************************************************/

#include "BinaryNode.hpp"
#include <cstddef>

/* Default Constructor */
template <class T>
BinaryNode<T>::BinaryNode() : item_(nullptr), leftChildPtr(nullptr), rightChildPtr(nullptr)
{
}

/* One-Parameter Constructor */
template <class T>
BinaryNode<T>::BinaryNode(const T &anItem)
    : item_(anItem), leftChildPtr(nullptr), rightChildPtr(nullptr)
{
}

/* Parameterized Constructor */
template <class T>
BinaryNode<T>::BinaryNode(const T &anItem,
                          std::shared_ptr<BinaryNode<T>> leftPtr,
                          std::shared_ptr<BinaryNode<T>> rightPtr)
    : item_(anItem), leftChildPtr(leftPtr), rightChildPtr(rightPtr)
{
}

/* Setter: item_ */
template <class T>
void BinaryNode<T>::setItem(const T &anItem)
{
   item_ = anItem;
}

/* Accessor: item_ */
template <class T>
T BinaryNode<T>::getItem() const
{
   return item_;
}

// returns whether a node is a leaf
template <class T>
bool BinaryNode<T>::isLeaf() const
{
   return ((leftChildPtr == nullptr) && (rightChildPtr == nullptr));
}

/* Setter: leftChildPtr */
template <class T>
void BinaryNode<T>::setLeftChildPtr(std::shared_ptr<BinaryNode<T>> leftPtr)
{
   leftChildPtr = leftPtr;
}

/* Setter: rightChildPtr */
template <class T>
void BinaryNode<T>::setRightChildPtr(std::shared_ptr<BinaryNode<T>> rightPtr)
{
   rightChildPtr = rightPtr;
}

/* Accessor: leftChildPtr */
template <class T>
auto BinaryNode<T>::getLeftChildPtr() const
{
   return leftChildPtr;
}

/* Accessor: rightChildPtr */
template <class T>
auto BinaryNode<T>::getRightChildPtr() const
{
   return rightChildPtr;
}
