/****************************************************************************************************************************
Title :       DynamicArray.cpp
Auhor :       Nigel Ferrer
Description : implementation file of a dynamically resizeable array class
Dependencies: DynamicArray.hpp
Addendum:     DO NOT ALTER THIS FILE
****************************************************************************************************************************/

#include <iostream>

/****************************************************** Public Methods *****************************************************/

/* Default Constructor */
template <class T>
DynamicArray<T>::DynamicArray() : current_capacity_{1}, item_count_{0} // initializer list
{
    items_ = new T[current_capacity_]; /* initializes items_ to a dynamically 
                                           allocated array of size 
                                           current_capacity_ */
}

/* Destructor */
template <class T>
DynamicArray<T>::~DynamicArray()
{
    clear(); /* clear() releases dynamically allocated
                   memory - we want to repeat this behavior
                   in other methods, which is why the code 
                   in clear() is in its own function as 
                   opposed to simply being in the destructor */
}

/** 
    implements addition of an item of type T to the end of the caller
    @param new_entry to be added to the caller
    @post if successful, the caller contains the new_entry
    @return true if the addition was successful; false otherwise
*/
template <class T>
bool DynamicArray<T>::add(const T &new_entry)
{
    try
    {
        size_t new_item_count = item_count_ + 1;
        if (atCapacity())
        {
            resize();
        }

        if (items_ == nullptr)
        {
            items_ = new T[1];
        }

        items_[item_count_] = new_entry;
        item_count_ = new_item_count;
        return true;
    }
    catch (...)
    {
        return false;
    }
}

/**
    returns whether the caller contains parameter 
        T an_entry by checking whether its index 
        is above sentinel value -1
*/
template <class T>
bool DynamicArray<T>::contains(const T &an_entry) const
{
    return getIndexOf(an_entry) > -1;
}

/**
    returns whether the caller contains no items
 */
template <class T>
bool DynamicArray<T>::isEmpty() const
{
    return item_count_ == 0;
}

/** 
    implements the removal of the first instance of parameter 
        an_item from the caller
    @param an_item to be removed from the caller
    @post if successful, the first instance of an_item has been 
        has been removed from the dynamic array 
    @return true if the removal was successful; false otherwise
*/
template <class T>
bool DynamicArray<T>::remove(const T &an_item)
{
    try
    {
        int found_index = getIndexOf(an_item);
        size_t old_capacity = getCapacity();
        int new_item_count = getOccupiedSpaces() - 1;
        bool can_remove = !isEmpty() && (found_index > -1);
        if (can_remove)
        {
            T *removed = new T[current_capacity_];

            int i = 0;
            int j = 0;
            for (size_t i = 0; i < current_capacity_; i++)
            {
                if (i == found_index)
                {
                    j++;
                }

                if (j < current_capacity_)
                {
                    removed[i] = items_[j];
                }
                j++;
            }
            clear();
            setItems(removed, new_item_count);
            current_capacity_ = old_capacity;
        }
        if (item_count_ <= current_capacity_ / 2)
        {
            resize();
        }
        return can_remove;
    }
    catch (...)
    {
        return false;
    }

    return true;
}

/**
    reassigns the caller's items_ array to parameter new_items_arr
    @param new_items_arr is a pointer to the first element of the
        array to which items_ will be assigned
    @param size is the number of entries in new_items_arr
    @post if successful, the items_ array has been assigned to new_items_arr
    @return true if the reassignment was successful; false otherwise
*/
template <class T>
bool DynamicArray<T>::setItems(T *new_items_arr, const size_t &size)
{
    try
    {
        clear();
        item_count_ = size;
        items_ = new_items_arr;
        return true;
    }
    catch (...)
    {
        return false;
    }
}

/**
    return the frequency of occurence of parameter an_entry
        in the caller
*/
template <class T>
int DynamicArray<T>::getFrequencyOf(const T &an_entry) const
{
    int frequency = 0;
    int cun_index = 0; // Current array index
    while (cun_index < item_count_)
    {
        if (items_[cun_index] == an_entry)
        {
            frequency++;
        } // end if

        cun_index++; // Increment to next entry
    }                // end while

    return frequency;
}

/* Accessor: current_capacity_ */
template <class T>
size_t DynamicArray<T>::getCapacity() const
{
    return current_capacity_;
}

/* Accessor: item_count_ */
template <class T>
size_t DynamicArray<T>::getOccupiedSpaces() const
{
    return item_count_;
}

/* Accessor: items_ */
template <class T>
T *DynamicArray<T>::getItems() const
{
    return items_;
}

/** 
    copies the items of the calling dynamic array
        into a vector and returns that vector
*/
template <class T>
std::vector<T> DynamicArray<T>::toVector() const
{
    std::vector<T> arr_contents;
    for (size_t i = 0; i < item_count_; i++)
    {
        arr_contents.push_back(items_[i]);
    }
    return arr_contents;
}

/**
    Releases dynamically allocated data and 
        handles the potential dangling pointer 
        that could be items_
*/
template <class T>
void DynamicArray<T>::clear()
{
    delete[] items_;
    item_count_ = 0;
    items_ = nullptr;
    current_capacity_ = 1;
}

/** 
    prints items of the caller line by line with 
        their corresponding index rankings    
 */
template <class T>
void DynamicArray<T>::displayOrderedNames()
{
    for (size_t i = 0; i < item_count_; i++)
    {
        std::cout << i << ". " << items_[i].getName() << std::endl;
    }
}

/** 
    swaps the positions of parameters i and j 
        in the caller
*/
template <class T>
void DynamicArray<T>::swap(const int &i, const int &j)
{
    T temp = items_[i];
    items_[i] = items_[j];
    items_[j] = temp;
}

/**************************************************** Operator Overloads ***************************************************/

template <class T>
void DynamicArray<T>::operator+(T rhs)
{
    add(rhs);
}

template <class T>
void DynamicArray<T>::operator-(const T &rhs)
{
    remove(rhs);
}

template <class T>
T DynamicArray<T>::operator[](const size_t &index)
{
    return items_[index];
}

template <class T>
bool DynamicArray<T>::operator==(const DynamicArray<T> &rhs) const
{
    bool param_flag = false;
    size_t same_elements = 0;
    if (item_count_ == rhs.getOccupiedSpaces() && current_capacity_ == rhs.getCapacity())
    {
        param_flag = true;
    }

    if (param_flag == false)
    {
        return false;
    }

    for (size_t i = 0; i < rhs.getOccupiedSpaces(); i++)
    {
        if (items_[i] == rhs.getItems()[i])
        {
            same_elements++;
        }
    }

    return same_elements == getOccupiedSpaces();
}

/***************************************************** Private Methods *****************************************************/

/**
    returns whether the caller is full
    @pre item_count_ > -1
    @return true if the caller is at capacity; false otherwise
*/
template <class T>
bool DynamicArray<T>::atCapacity() const
{
    return item_count_ == current_capacity_;
}

/**
    @param target an object of type T that will be 
        parsed sought after in the caller
    @return the index of target if it is in the caller;
        -1 otherwise 
*/
template <class T>
int DynamicArray<T>::getIndexOf(const T &target) const
{
    bool found = false;
    int result = -1;
    int search_index = 0;

    // If the bag is empty, item_count_ is zero, so loop is skipped
    while (!found && (search_index < item_count_))
    {
        if (items_[search_index] == target)
        {
            found = true;
            result = search_index;
        }
        else
        {
            search_index++;
        } // end if
    }     // end while
    return result;
} // end getIndexOf

/* 
    copies the elements of items_ into a new dynamically allocated
        array which is either twice or half the size of current_capacity_
        depending on whether the resize was called because of an addition
        or a removal
*/
template <class T>
void DynamicArray<T>::resize()
{
    int new_size = 0;
    if (!atCapacity())
    {
        new_size = current_capacity_ / 2;
    }
    else
    {
        new_size = 2 * current_capacity_;
    }
    T *resized = new T[new_size];
    for (size_t i = 0; i < item_count_; i++)
    {
        resized[i] = items_[i];
    }
    current_capacity_ = new_size;
    items_ = resized;
    return;
}