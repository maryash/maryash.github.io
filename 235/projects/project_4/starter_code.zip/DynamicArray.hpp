/****************************************************************************************************************************
Title :       DynamicArray.hpp
Auhor :       Nigel Ferrer
Description : header/interface file of a dynamically resizeable array class
Addendum:     DO NOT ALTER THIS FILE
****************************************************************************************************************************/

#ifndef DYNAMIC_ARRAY_
#define DYNAMIC_ARRAY_

#include <vector>

template <class T>
class DynamicArray
{

public:
    DynamicArray();
    ~DynamicArray();
    bool add(const T &new_entry);
    bool contains(const T &an_entry) const;
    bool isEmpty() const;
    bool remove(const T &an_item);
    bool setItems(T *new_items_arr, const size_t &size = 0);
    int getFrequencyOf(const T &an_entry) const;
    size_t getCapacity() const;
    size_t getOccupiedSpaces() const;
    T *getItems() const;
    std::vector<T> toVector() const;
    void clear();
    void displayOrderedNames();
    void swap(const int &i, const int &j);

    void operator+(T rhs);
    void operator-(const T &rhs);
    T operator[](const size_t &index);
    bool operator==(const DynamicArray<T> &rhs) const;

    int getIndexOf(const T &target) const;

private:
    bool atCapacity() const;
    void resize();
    size_t current_capacity_;
    size_t item_count_;
    T *items_;
}; // end DynamicArray

#include "DynamicArray.cpp"
#endif
