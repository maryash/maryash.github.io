/****************************************************************************************************************************
Title :       GridInterface.hpp
Auhor :       Nigel Ferrer
Description : header/interface file of a dynamically resizable square grid ADT
Addendum:     DO NOT ALTER THIS FILE
****************************************************************************************************************************/

#ifndef GRID_INTERFACE_
#define GRID_INTERFACE_

template <class ItemType>
class GridInterface
{
public:
  /* Destructor */
  virtual ~GridInterface(){};

  /** 
      adds a new entry to the caller
      @param new_entry the object to be added
      @post if successful, new_entry is stored in the caller and
              num_items_ is incremented; additionally calls 
              resize() if num_items_ > grid_capacity
      @return true if addition was successful; false otherwise 
  */
  virtual bool add(const ItemType &new_entry) = 0;

  /** 
      tests whether the caller contains a given entry.
      @param an_entry the entry to locate
      @return true if the caller contains an_entry; false otherwise. 
  */
  virtual bool contains(const ItemType &an_entry) const = 0;

  /** 
    removes the last entry from the caller
    @post if successful, the last entry has been removed from the caller
            and num_items_ has been decremented; additionally calls
            resize() if sqrt(num_items_) is an integer 
     @param an_entry the entry to be removed
     @return true if removal was successful; false otherwise 
  */
  virtual bool pop_back() = 0;

  /** 
      returns the number of times a given entry appears in the caller
      @param an_entry the entry to be counted
      @return the number of times an_entry appears in the caller
  */
  virtual int getFrequencyOf(const ItemType &an_entry) const = 0;

  /** 
      removes all entries from the caller
      @post num_items_ == 0, grid_capacity == 0
  */
  virtual void clear() = 0;

protected:
  /** 
      resizes grid_capicity_:

        CASE (num_items_ > grid_capacity_): 
                grid_capacity_ <- the smallest perfect square
                                  >= num_items_

        CASE (grid_capacity_ > num_items_ && sqrt(num_items) is an integer): 
                grid_capacity <- num_items_
                  
                !!!!! THIS FUNCTION MUST CALL REPOSITION !!!!!

      @post grid_capacity <- one of the aforementioned values
      @return true if resize was successful; false otherwise 
  */
  virtual bool resize() = 0;

  /** 
      reorients the caller's items to fill as much ordered space as possible
                when resize() is called
      @post the caller's items have been properly repositioned; the only 
                empty space that may remain is at the end of the grid
      @return true if reposition was successful; false otherwise
  */
  virtual bool reposition() = 0;
}; // end GridInterface

#endif